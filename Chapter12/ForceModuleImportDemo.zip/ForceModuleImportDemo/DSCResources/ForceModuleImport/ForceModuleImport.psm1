﻿function Get-TargetResource
{
    param
    (
        [Parameter(Mandatory = $true)]
        [String]
        $DummyKey
    )
    return @{DummyKey = ''}
}

function Set-TargetResource
{
    param
    (
        [Parameter(Mandatory = $true)]
        [String]
        $DummyKey
    )

    Write-Verbose -Message "There is no real set operation here! DummyKey is $DummyKey"
}

function Test-TargetResource
{
    param
    (
        [Parameter(Mandatory = $true)]
        [String]
        $DummyKey
    )

    #See that we are not returning anything here!
}